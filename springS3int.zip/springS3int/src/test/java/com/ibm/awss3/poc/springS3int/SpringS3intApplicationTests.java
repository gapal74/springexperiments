package com.ibm.awss3.poc.springS3int;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringS3intApplicationTests {

	@Test
	void contextLoads() {
	}

}
