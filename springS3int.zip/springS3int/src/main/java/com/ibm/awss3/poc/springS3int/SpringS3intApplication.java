package com.ibm.awss3.poc.springS3int;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringS3intApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringS3intApplication.class, args);
	}

}
